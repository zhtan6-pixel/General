Project Portfolio Report (5 pages)

Overview
- Purpose: Recreate a 5-page Power BI report based on the provided HTML example, using the existing dataset named `ProjectDate`.
- Output: report spec, DAX measures, field mappings, and step-by-step Power BI Desktop instructions.

Files
- `report-spec.md`  page-by-page layout and visuals
- `field-mappings.md`  expected dataset fields and recommended types
- `dax-measures.dax`  reusable DAX measures to paste into Power BI
- `instructions.md`  how to import, build, and finalize the report in Power BI Desktop

Next steps
- Open your Power BI Desktop file (the open report) and follow `instructions.md` to add pages and measures.
