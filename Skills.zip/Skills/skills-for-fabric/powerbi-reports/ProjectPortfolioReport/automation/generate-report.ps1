<#
GenerateReport.ps1

Overview:
- Extracts a .pbix using pbi-tools, runs a Tabular Editor script to add measures,
- Appends placeholder pages from the `templates/pages` folder into the report JSON,
- Repackages the PBIX.

Requirements:
- PowerShell (Windows)
- dotnet SDK (for pbi-tools) or pbi-tools installed as a dotnet global tool
- pbi-tools (https://pbi.tools/) installed (`dotnet tool install -g pbi-tools`)
- Tabular Editor 2 or 3 installed (CLI path provided to script)

Usage:
.
.
PS> .\generate-report.ps1 -PbixPath "C:\path\to\your\report.pbix" -TabularEditorPath "C:\Program Files\Tabular Editor\TabularEditor.exe"

#>
param(
    [Parameter(Mandatory=$true)]
    [string]$PbixPath,
    [string]$OutPbixPath = "$PWD\generated\report.generated.pbix",
    [string]$TabularEditorPath = "C:\\Program Files\\Tabular Editor\\TabularEditor.exe",
    [string]$TemplatesDir = "$PSScriptRoot\templates\pages"
)

Set-StrictMode -Version Latest

if (-not (Test-Path $PbixPath)) { throw "PBIX not found: $PbixPath" }

# Ensure pbi-tools is available
try {
    $pbi = Get-Command pbi-tools -ErrorAction Stop
} catch {
    Write-Host "pbi-tools not found. Installing (requires dotnet SDK)..." -ForegroundColor Yellow
    dotnet tool install -g pbi-tools
}

$workDir = Join-Path $PSScriptRoot "work_$(Get-Date -Format 'yyyyMMddHHmmss')"
New-Item -ItemType Directory -Path $workDir -Force | Out-Null

Write-Host "Extracting PBIX..." -ForegroundColor Cyan
pbi-tools extract --input "$PbixPath" --output "$workDir\extracted" | Out-Null

# Locate the extracted Report JSON file
$reportJsonPath = Get-ChildItem -Path "$workDir\extracted" -Recurse -Filter "Report.json" -ErrorAction SilentlyContinue | Select-Object -First 1
if (-not $reportJsonPath) { throw "Could not find Report.json in extracted PBIX. Extraction may have failed or pbi-tools layout changed." }
$reportJsonFile = $reportJsonPath.FullName

Write-Host "Report JSON: $reportJsonFile" -ForegroundColor Green

# Backup original
Copy-Item -Path $reportJsonFile -Destination "$reportJsonFile.bak" -Force

# Load report JSON
$reportObj = Get-Content $reportJsonFile -Raw | ConvertFrom-Json

# Append pages from templates (each template is a minimal JSON page structure)
if (Test-Path $TemplatesDir) {
    $templateFiles = Get-ChildItem -Path $TemplatesDir -Filter "*.json" -File | Sort-Object Name
    foreach ($t in $templateFiles) {
        Write-Host "Appending template: $($t.Name)" -ForegroundColor Cyan
        $pageObj = Get-Content $t.FullName -Raw | ConvertFrom-Json
        if (-not $reportObj.pages) { $reportObj | Add-Member -MemberType NoteProperty -Name pages -Value @() -Force }
        $pages = @($reportObj.pages) + ,$pageObj
        $reportObj.pages = $pages
    }
    # Save modified report JSON
    $reportObj | ConvertTo-Json -Depth 200 | Out-File -FilePath $reportJsonFile -Encoding UTF8
} else {
    Write-Host "No templates folder found at $TemplatesDir — skipping page append." -ForegroundColor Yellow
}

# Add measures using Tabular Editor (if available)
$modelBim = Get-ChildItem -Path "$workDir\extracted" -Recurse -Filter "model.bim" | Select-Object -First 1
if ($modelBim) {
    Write-Host "Found model.bim at $($modelBim.FullName)" -ForegroundColor Green
    $scriptPath = Join-Path $PSScriptRoot "add-measures.cs"
    if (-not (Test-Path $scriptPath)) { Write-Host "Tabular Editor script not found: $scriptPath" -ForegroundColor Yellow } else {
        if (-not (Test-Path $TabularEditorPath)) { Write-Host "Tabular Editor not found at $TabularEditorPath. Please install and provide the correct path." -ForegroundColor Yellow } else {
            Write-Host "Running Tabular Editor to add measures..." -ForegroundColor Cyan
            & "$TabularEditorPath" "$($modelBim.FullName)" -S "$scriptPath"
        }
    }
} else {
    Write-Host "model.bim not found in extracted folder — skipping measure injection." -ForegroundColor Yellow
}

Write-Host "Repackaging PBIX..." -ForegroundColor Cyan
New-Item -ItemType Directory -Path (Split-Path $OutPbixPath) -Force | Out-Null
pbi-tools restore --input "$workDir\extracted" --output "$OutPbixPath" | Out-Null

Write-Host "Generated PBIX: $OutPbixPath" -ForegroundColor Green
Write-Host "Done. Open the new PBIX in Power BI Desktop to review pages and visuals." -ForegroundColor Green
