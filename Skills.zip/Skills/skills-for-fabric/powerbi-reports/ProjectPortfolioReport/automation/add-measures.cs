// Tabular Editor C# script to add measures to the Projects table
// Usage: TabularEditor.exe model.bim -S add-measures.cs
var table = Model.Tables.Find("Projects");
if (table == null) {
    table = Model.Tables.Add("Projects");
}

var measures = new [] {
    new { Name = "Total Projects", Expression = "DISTINCTCOUNT('Projects'[ProjectID])" },
    new { Name = "Active Projects", Expression = "CALCULATE([Total Projects], FILTER(ALL('Projects'), 'Projects'[Status] = \"Active\"))" },
    new { Name = "Completed Projects", Expression = "CALCULATE([Total Projects], FILTER(ALL('Projects'), 'Projects'[Status] = \"Completed\"))" },
    new { Name = "Total Budget", Expression = "SUM('Projects'[Budget])" },
    new { Name = "Total Actual Cost", Expression = "SUM('Projects'[ActualCost])" },
    new { Name = "Budget Variance", Expression = "[Total Budget] - [Total Actual Cost]" },
    new { Name = "Percent Complete (Avg)", Expression = "AVERAGE('Projects'[PercentComplete])" },
    new { Name = "High Risk Count", Expression = "CALCULATE(COUNTA('Projects'[ProjectID]), FILTER(ALL('Projects'), 'Projects'[RiskLevel] = \"High\"))" },
};

foreach (var m in measures) {
    var existing = table.Measures.Find(m.Name);
    if (existing == null) {
        var measure = table.Measures.Add(m.Name, m.Expression);
        measure.FormatString = "#,0.00";
    } else {
        existing.Expression = m.Expression;
    }
}

Model.SaveChanges();
