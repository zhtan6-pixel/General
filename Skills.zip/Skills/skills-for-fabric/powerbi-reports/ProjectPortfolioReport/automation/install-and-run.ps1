<#
install-and-run.ps1

Automates installing .NET SDK (via winget when available), installs pbi-tools, and runs the report generator.

Run as Administrator in PowerShell (may require elevation for winget install).

Usage:
.
PS> .\install-and-run.ps1 -PbixPath "C:\path\to\report.pbix"

#>
param(
    [Parameter(Mandatory=$true)]
    [string]$PbixPath,
    [string]$GeneratorScript = $null,
    [string]$OutPbixPath = $null
)

Set-StrictMode -Version Latest

# Resolve default paths relative to the script folder
if (-not $GeneratorScript) { $GeneratorScript = Join-Path $PSScriptRoot 'generate-report.ps1' }
if (-not $OutPbixPath) { $OutPbixPath = Join-Path $PSScriptRoot 'generated\report.generated.pbix' }

# Ensure output directory exists
New-Item -ItemType Directory -Path (Split-Path $OutPbixPath) -Force | Out-Null

function Write-ErrAndExit($msg, $code=1) {
    Write-Error $msg
    exit $code
}

if (-not (Test-Path $PbixPath)) { Write-ErrAndExit "PBIX not found: $PbixPath" }
if (-not (Test-Path $GeneratorScript)) { Write-ErrAndExit "Generator script not found: $GeneratorScript" }

# Check for dotnet
if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) {
    Write-Host "dotnet SDK not found." -ForegroundColor Yellow
    if (Get-Command winget -ErrorAction SilentlyContinue) {
        Write-Host "winget detected - attempting to install .NET SDK (may require elevation)" -ForegroundColor Cyan
        try {
            winget install --id Microsoft.DotNet.SDK.7 -e --accept-package-agreements --accept-source-agreements
        } catch {
            Write-Host "winget install failed or requires manual acceptance. Please run the following manually or install .NET SDK from https://dotnet.microsoft.com/download" -ForegroundColor Red
            Write-Host "winget command: winget install --id Microsoft.DotNet.SDK.7 -e --accept-package-agreements --accept-source-agreements" -ForegroundColor Red
            exit 2
        }
    } else {
        Write-Host "winget not available. Please install the .NET SDK manually from https://dotnet.microsoft.com/download" -ForegroundColor Red
        exit 3
    }
} else {
    Write-Host "dotnet found:" -ForegroundColor Green
    dotnet --info | Select-String 'SDK' | ForEach-Object { Write-Host $_ }
}

# Install or update pbi-tools
try {
    dotnet tool install -g pbi-tools -v minimal
    Write-Host "pbi-tools installed." -ForegroundColor Green
} catch {
    Write-Host "Install may have failed or pbi-tools already installed; trying update..." -ForegroundColor Yellow
    try { dotnet tool update -g pbi-tools -v minimal; Write-Host "pbi-tools updated." -ForegroundColor Green } catch { Write-Host "pbi-tools install/update failed: $($_.Exception.Message)" -ForegroundColor Red; exit 4 }
}

# Ensure dotnet tools path in session
$dotnetTools = Join-Path $env:USERPROFILE '.dotnet\tools'
if (Test-Path $dotnetTools) {
    $env:PATH = $dotnetTools + ';' + $env:PATH
    Write-Host "Added $dotnetTools to PATH for session" -ForegroundColor Green
}

# Verify pbi-tools
try {
    $ver = & pbi-tools --version
    Write-Host "pbi-tools version: $ver" -ForegroundColor Green
} catch {
    Write-Host "pbi-tools not available after install. You may need to restart the shell or sign out/in." -ForegroundColor Red
    Write-Host "Ensure $dotnetTools is in your PATH and reopen PowerShell." -ForegroundColor Yellow
    exit 5
}

# Run the generator script (skip Tabular Editor injection)
Write-Host "Running generator: $GeneratorScript" -ForegroundColor Cyan
& powershell -NoProfile -ExecutionPolicy Bypass -File $GeneratorScript -PbixPath $PbixPath -OutPbixPath $OutPbixPath

Write-Host 'Installer script completed.' -ForegroundColor Green
