<#
modify-extracted.ps1

Injects placeholder pages and DAX measures into a pbi-tools extracted PBIX folder.

Usage (assumes you used the pbi-tools VS Code extension to extract into folder):
PS> .\modify-extracted.ps1 -ExtractedPath "C:\path\to\extracted\folder"

After running, use the pbi-tools extension (or CLI) to `restore` the folder back to a PBIX.
#>
param(
    [Parameter(Mandatory=$true)]
    [string]$ExtractedPath
)

Set-StrictMode -Version Latest

if (-not (Test-Path $ExtractedPath)) { throw "Extracted folder not found: $ExtractedPath" }

$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$templatesDir = Join-Path $scriptRoot 'templates\pages'

# Append pages
$reportJsonPath = Get-ChildItem -Path $ExtractedPath -Recurse -Filter 'Report.json' -File | Select-Object -First 1
if (-not $reportJsonPath) { throw "Report.json not found under extracted folder" }
$reportJsonFile = $reportJsonPath.FullName
Write-Host "Loading Report.json: $reportJsonFile"
$report = Get-Content $reportJsonFile -Raw | ConvertFrom-Json

if (-not (Test-Path $templatesDir)) { Write-Host "Templates dir missing: $templatesDir" }
else {
    $templates = Get-ChildItem -Path $templatesDir -Filter '*.json' -File | Sort-Object Name
    foreach ($t in $templates) {
        Write-Host "Appending template page: $($t.Name)"
        $pageObj = Get-Content $t.FullName -Raw | ConvertFrom-Json
        if (-not $report.pages) { $report.pages = @() }
        $report.pages = ,$report.pages + ,$pageObj
    }
    # Save back
    $report | ConvertTo-Json -Depth 200 | Out-File -FilePath $reportJsonFile -Encoding UTF8
    Write-Host "Saved modified Report.json"
}

# Inject measures into model.bim
$modelBim = Get-ChildItem -Path $ExtractedPath -Recurse -Filter 'model.bim' -File | Select-Object -First 1
if (-not $modelBim) { Write-Host 'model.bim not found, skipping measure injection'; exit 0 }
$modelFile = $modelBim.FullName
Write-Host "Loading model.bim: $modelFile"
$model = Get-Content $modelFile -Raw | ConvertFrom-Json

# Ensure tables array
if (-not $model.tables) { $model | Add-Member -MemberType NoteProperty -Name tables -Value @() -Force }
$tables = $model.tables
$projectsTable = $tables | Where-Object { $_.name -eq 'Projects' }
if (-not $projectsTable) {
    Write-Host "Projects table not found; creating minimal Projects table entry"
    $projectsTable = @{ name = 'Projects'; columns = @(); measures = @(); annotations = @() }
    $model.tables += $projectsTable
}
if (-not $projectsTable.measures) { $projectsTable.measures = @() }

# Define measures to add
$measures = @(
    @{ name = 'Total Projects'; expression = "DISTINCTCOUNT('Projects'[ProjectID])"; format = "#,0" },
    @{ name = 'Active Projects'; expression = "CALCULATE([Total Projects], FILTER(ALL('Projects'), 'Projects'[Status] = \"Active\"))"; format = "#,0" },
    @{ name = 'Completed Projects'; expression = "CALCULATE([Total Projects], FILTER(ALL('Projects'), 'Projects'[Status] = \"Completed\"))"; format = "#,0" },
    @{ name = 'Total Budget'; expression = "SUM('Projects'[Budget])"; format = "#,0.00" },
    @{ name = 'Total Actual Cost'; expression = "SUM('Projects'[ActualCost])"; format = "#,0.00" },
    @{ name = 'Budget Variance'; expression = "[Total Budget] - [Total Actual Cost]"; format = "#,0.00" },
    @{ name = 'Percent Complete (Avg)'; expression = "AVERAGE('Projects'[PercentComplete])"; format = "0.00%" },
    @{ name = 'High Risk Count'; expression = "CALCULATE(COUNTA('Projects'[ProjectID]), FILTER(ALL('Projects'), 'Projects'[RiskLevel] = \"High\"))"; format = "#,0" }
)

foreach ($m in $measures) {
    $exists = $projectsTable.measures | Where-Object { $_.name -eq $m.name }
    if ($exists) { Write-Host "Measure '$($m.name)' already exists - skipping"; continue }
    $measureObj = @{
        name = $m.name
        expression = $m.expression
        formatString = $m.format
    }
    $projectsTable.measures += $measureObj
    Write-Host "Added measure: $($m.name)"
}

# Save model.bim
$model | ConvertTo-Json -Depth 200 | Out-File -FilePath $modelFile -Encoding UTF8
Write-Host "Saved modified model.bim"

Write-Host "Modify-extracted complete. Use pbi-tools (VS Code extension or CLI) to restore the folder to a PBIX."