Project Portfolio Report — Page-by-page spec

Page 1 — Executive Summary
- Title: Project Portfolio Dashboard
- Visuals:
  - Card: Total Projects
  - Card: Active Projects
  - Card: Completed Projects
  - Clustered bar chart: Projects by Business Unit
  - Line chart: Cumulative Projects over time (by Project Start Date)
  - KPI grid: Top 5 projects by budget (table with conditional formatting)

Page 2 — Timeline & Status
- Visuals:
  - Gantt / stacked bar (use "Gantt" custom visual or use stacked bar by Month)
  - Slicer: Project Status
  - Matrix: Project Name, Start Date, End Date, Percent Complete
  - Line chart: Planned vs Actual completion (if Actual% exists)

Page 3 — Financials
- Visuals:
  - Card: Total Budget
  - Card: Total Actual Cost
  - Waterfall: Budget -> Spent -> Remaining
  - Donut chart: Budget by Cost Center
  - Table: Projects with Budget, Actual, Variance (Budget-Actual)

Page 4 — Risk & Issues
- Visuals:
  - Stacked column: Risk Level counts (Low/Medium/High)
  - Table: Open Issues with Severity and Owner
  - KPI: Number of High Risks
  - Slicer: Risk Owner

Page 5 — Resources & Schedule
- Visuals:
  - Clustered bar: Resource allocation by role
  - Table: Resource Name, Assigned Projects, % Allocation
  - Line chart: Workload over time
  - Slicer: Resource Role

Notes
- Use `ProjectDate` as the date table or connect to an existing date table; mark it as date table in model.
- Use standard color palette matching your organization (optional).
