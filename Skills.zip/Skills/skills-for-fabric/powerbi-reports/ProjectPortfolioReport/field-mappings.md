Field mappings — expected fields on `ProjectDate` dataset

Core project table (expected fields)
- ProjectID (Text/ID)
- ProjectName (Text)
- BusinessUnit (Text)
- Status (Text) — e.g., Active, Completed, On Hold
- StartDate (Date)
- EndDate (Date)
- Budget (Currency/Decimal)
- ActualCost (Currency/Decimal)
- PercentComplete (Decimal 0-100)
- CostCenter (Text)
- RiskLevel (Text) — Low/Medium/High
- ResourceName (Text)
- ResourceRole (Text)
- IssuesOpen (Integer)
- IssueSeverity (Text)

Date table
- Date (Date)
- Year
- Quarter
- Month
- MonthNumber
- Week

Notes
- If your dataset uses different field names, map them in the model or rename columns in Power Query.
- Ensure `StartDate` and `EndDate` are typed as Date and use `ProjectDate` as the date table if it contains the needed range.
