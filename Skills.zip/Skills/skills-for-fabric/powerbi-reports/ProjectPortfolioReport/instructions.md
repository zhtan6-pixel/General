Step-by-step: add 5 pages to your open Power BI Desktop report

Prerequisites
- Power BI Desktop installed
- Your open report connected to dataset named `ProjectDate`

1) Backup
- Save a copy of your current `.pbix` file before making changes.

2) Create measures
- Open `Modeling` → `New measure` and paste measures from `dax-measures.dax`.

3) Page 1 — Executive Summary
- Add a new page, set title to "Project Portfolio Dashboard".
- Add three Card visuals and assign `Total Projects`, `Active Projects`, `Completed Projects`.
- Add a clustered bar chart: Axis = `BusinessUnit`, Value = `Total Projects` (use `Total Projects` measure or count of ProjectID).
- Add a line chart: Axis = `Date` (from `ProjectDate` table), Value = `Cumulative Projects`.
- Add table visual: Top 5 projects by `Budget` with conditional formatting on `Budget`.

4) Page 2 — Timeline & Status
- Add Gantt visual or stacked bar by month. Use `StartDate` and `EndDate`.
- Add slicer for `Status`.
- Add matrix: `ProjectName`, `StartDate`, `EndDate`, `PercentComplete`.

5) Page 3 — Financials
- Add cards: `Total Budget`, `Total Actual Cost`.
- Add waterfall visual: use `Budget`, `ActualCost` measures to show remaining.
- Add donut: `CostCenter` as Legend, `Total Budget` as Value.
- Add table with `ProjectName`, `Budget`, `ActualCost`, `Budget Variance`.

6) Page 4 — Risk & Issues
- Add stacked column: Axis = `RiskLevel`, Value = `ProjectID` (count) or `High Risk Count` measure.
- Add table: `ProjectName`, `IssuesOpen`, `IssueSeverity`, filter to open issues.
- Add card: `High Risk Count`.

7) Page 5 — Resources & Schedule
- Add clustered bar: `ResourceRole` axis, Value = `Assigned Projects` (count of ProjectID).
- Add table: `ResourceName`, `Assigned Projects`, `% Allocation` (if available).
- Add line: `Date` vs resource workload (if allocation over time exists).

8) Finalize
- Apply consistent theme: `View` → `Themes` → choose or import JSON.
- Set `ProjectDate` as the Date table: `Modeling` → `Mark as date table`.
- Save and publish to Power BI Service if desired.

Notes and troubleshooting
- If a visual requires a custom visual (e.g., Gantt), download it from AppSource and import via `Visualizations` → `Import from marketplace`.
- If measures produce blank values, check relationships between `Projects` and `ProjectDate` tables.

